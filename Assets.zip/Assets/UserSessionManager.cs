using UnityEngine;
using System;

[System.Serializable]
public class StudentManagerUserData
{
    public int user_id;
    public string name;
    public string email;
    public DateTime lastLogin;

    public StudentManagerUserData(UserData authData)
    {
        if (authData != null)
        {
            this.user_id = authData.user_id;
            this.name = authData.name;
            this.email = authData.email;
            this.lastLogin = authData.lastLogin;
        }
    }
}

public class UserSessionManager : MonoBehaviour
{
    private static UserSessionManager _instance;
    private const string USER_PREFS_KEY = "USER_SESSION_DATA";

    public delegate void UserLoginHandler(int userId);
    public static event UserLoginHandler OnUserLogin;

    public static UserSessionManager Instance
    {
        get { return _instance; }
    }

    public StudentManagerUserData CurrentUser { get; private set; }
    public bool IsLoggedIn => CurrentUser != null && CurrentUser.user_id > 0;

    private void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);

            UserData authUser = AuthManager.GetLastLoggedInUser();
            if (authUser != null)
            {
                CurrentUser = new StudentManagerUserData(authUser);
                SaveUserData();
                Debug.Log($"UserSessionManager: Loaded user from auth transition: {CurrentUser.name}");

                if (OnUserLogin != null && IsLoggedIn)
                {
                    OnUserLogin(CurrentUser.user_id);
                }
            }
            else
            {
                LoadUserData();

                if (OnUserLogin != null && IsLoggedIn)
                {
                    OnUserLogin(CurrentUser.user_id);
                }
            }
        }
        else if (_instance != this)
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        if (IsLoggedIn)
        {
            Debug.Log($"UserSessionManager: User is logged in - {CurrentUser.name} (ID: {CurrentUser.user_id})");
        }
        else
        {
            Debug.Log("UserSessionManager: No user is logged in");
        }
    }

    public void Logout()
    {
        CurrentUser = null;
        PlayerPrefs.DeleteKey(USER_PREFS_KEY);
        PlayerPrefs.Save();

        Debug.Log("UserSessionManager: User logged out");
    }

    private void SaveUserData()
    {
        if (CurrentUser != null)
        {
            string userData = JsonUtility.ToJson(CurrentUser);
            PlayerPrefs.SetString(USER_PREFS_KEY, userData);
            PlayerPrefs.Save();
        }
    }

    private void LoadUserData()
    {
        if (PlayerPrefs.HasKey(USER_PREFS_KEY))
        {
            string userData = PlayerPrefs.GetString(USER_PREFS_KEY);
            try
            {
                CurrentUser = JsonUtility.FromJson<StudentManagerUserData>(userData);
                Debug.Log($"UserSessionManager: Loaded user data for: {CurrentUser.name}");
            }
            catch (Exception e)
            {
                Debug.LogError($"UserSessionManager: Error loading user data: {e.Message}");
                CurrentUser = null;
            }
        }
    }

    public int GetCurrentUserId()
    {
        return IsLoggedIn ? CurrentUser.user_id : -1;
    }

    public string GetCurrentUserName()
    {
        return IsLoggedIn ? CurrentUser.name : "Guest";
    }
}