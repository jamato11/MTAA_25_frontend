using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using TMPro;

[System.Serializable]
public class TaskData
{
    public int chat_id;
    public string date;
    public string time;
    public string title;
    public string description;
    public int owner_user_id;
}

public class ChatDataReturned
{
    public int chat_id;
    public string chat_name;
}

public class ChatListResponse
{
    public List<ChatDataReturned> chats;
}

public class TaskCreator : MonoBehaviour
{
    [Header("Task Input Fields")]
    [SerializeField] private TMP_InputField titleInputField;
    [SerializeField] private TMP_InputField descriptionInputField;
    [SerializeField] private TMP_InputField hourInputField;
    [SerializeField] private TMP_InputField dayInputField;
    [SerializeField] private TMP_InputField monthInputField;
    [SerializeField] private TMP_InputField yearInputField;

    [Header("UI References")]
    [SerializeField] private Button createButton;
    [SerializeField] private Button addCollaboratorsButton;
    [SerializeField] private GameObject collaboratorsPopup;
    [SerializeField] private Transform chatButtonsContainer;
    [SerializeField] private GameObject chatButtonPrefab;

    private int selectedChatId = 0;
    private List<ChatDataReturned> userChats = new List<ChatDataReturned>();
    private const string API_BASE_URL = "http://127.0.0.1:5000";

    private void Start()
    {
        createButton.onClick.AddListener(CreateTask);
        addCollaboratorsButton.onClick.AddListener(ShowCollaboratorsPopup);

        if (collaboratorsPopup != null)
            collaboratorsPopup.SetActive(false);
    }

    public void ShowCollaboratorsPopup()
    {
        collaboratorsPopup.SetActive(true);
        FetchUserChats();
    }

    public void CloseCollaboratorsPopup()
    {
        collaboratorsPopup.SetActive(false);
    }

    private void FetchUserChats()
    {
        int userId = UserSessionManager.Instance.GetCurrentUserId();
        if (userId <= 0)
        {
            Debug.LogError("No user is logged in");
            return;
        }

        string url = $"{API_BASE_URL}/users/{userId}/chats";
        StartCoroutine(GetUserChats(url));
    }

    private IEnumerator GetUserChats(string url)
    {
        using (UnityWebRequest request = UnityWebRequest.Get(url))
        {
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                string json = request.downloadHandler.text;
                ChatListResponse response = JsonUtility.FromJson<ChatListResponse>(json);

                if (response != null && response.chats != null)
                {
                    userChats = response.chats;
                    PopulateChatsUI();
                }
                else
                {
                    Debug.LogError("Failed to parse chats data: " + json);
                }
            }
            else
            {
                Debug.LogError("Error getting user chats: " + request.error);
            }
        }
    }

    private void PopulateChatsUI()
    {
        foreach (Transform child in chatButtonsContainer)
        {
            Destroy(child.gameObject);
        }

        CreateChatButton(new ChatDataReturned { chat_id = 0, chat_name = "No Collaboration" });

        foreach (ChatDataReturned chat in userChats)
        {
            CreateChatButton(chat);
        }
    }

    private void CreateChatButton(ChatDataReturned chat)
    {
        GameObject buttonObj = Instantiate(chatButtonPrefab, chatButtonsContainer);
        Button button = buttonObj.GetComponent<Button>();
        TextMeshProUGUI buttonText = buttonObj.GetComponentInChildren<TextMeshProUGUI>();

        if (buttonText != null)
            buttonText.text = chat.chat_name;

        button.onClick.AddListener(() => {
            selectedChatId = chat.chat_id;
            Debug.Log($"Selected chat: {chat.chat_name} (ID: {chat.chat_id})");
            CloseCollaboratorsPopup();
        });
    }

    public void CreateTask()
    {
        int userId = UserSessionManager.Instance.GetCurrentUserId();
        if (userId <= 0)
        {
            Debug.LogError("No user is logged in");
            return;
        }

        if (string.IsNullOrEmpty(titleInputField.text))
        {
            Debug.LogError("Task title cannot be empty");
            return;
        }

        string date = $"{yearInputField.text}-{monthInputField.text.PadLeft(2, '0')}-{dayInputField.text.PadLeft(2, '0')}";

        TaskData taskData = new TaskData
        {
            chat_id = selectedChatId,
            date = date,
            time = hourInputField.text.PadLeft(2, '0') + ":00",
            title = titleInputField.text,
            description = descriptionInputField.text,
            owner_user_id = userId
        };

        StartCoroutine(PostTaskToServer(taskData));
    }

    private IEnumerator PostTaskToServer(TaskData taskData)
    {
        string url = $"{API_BASE_URL}/tasks";
        string jsonData = JsonUtility.ToJson(taskData);

        Debug.Log($"Sending task data: {jsonData}");

        using (UnityWebRequest request = new UnityWebRequest(url, "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("Task created successfully!");
                SceneManager.LoadScene("Calendar");
            }
            else
            {
                Debug.LogError($"Error creating task: {request.error}");
            }
        }
    }
}