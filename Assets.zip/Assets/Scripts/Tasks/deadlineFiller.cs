using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class deadlineFiller : MonoBehaviour
{
    public TMP_Dropdown dayDropdown;
    public TMP_Dropdown monthDropdown;
    public TMP_Dropdown yearDropdown;
    public TMP_Dropdown hourDropdown;

    void Start()
    {
        FillDropdown(dayDropdown, 1, 31);
        FillDropdown(monthDropdown, 1, 12);
        FillDropdown(yearDropdown, 2020, 2030);
        FillDropdown(hourDropdown, 0, 23);
    }

    void FillDropdown(TMP_Dropdown dropdown, int start, int end)
    {
        dropdown.ClearOptions();
        List<string> options = new List<string>();

        for (int i = start; i <= end; i++)
        {
            options.Add(i.ToString("D2"));
        }

        dropdown.AddOptions(options);
    }  
}
