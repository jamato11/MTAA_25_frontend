using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuNavigation : MonoBehaviour
{
    [Header("Navigation Buttons")]
    [SerializeField] private GameObject settingsButton;
    [SerializeField] private GameObject pomodoroButton;
    [SerializeField] private GameObject calendarButton;
    [SerializeField] private GameObject chatButton;

    private void Start()
    {
        if (settingsButton == null || pomodoroButton == null ||
            calendarButton == null || chatButton == null)
        {
            Debug.LogWarning("Some buttons are not assigned in the MenuNavigation script!");
        }

        AddButtonListeners();
    }

    private void AddButtonListeners()
    {
        if (settingsButton != null)
        {
            settingsButton.GetComponent<UnityEngine.UI.Button>().onClick.AddListener(OpenSettings);
        }

        if (pomodoroButton != null)
        {
            pomodoroButton.GetComponent<UnityEngine.UI.Button>().onClick.AddListener(OpenPomodoroSettings);
        }

        if (calendarButton != null)
        {
            calendarButton.GetComponent<UnityEngine.UI.Button>().onClick.AddListener(OpenCalendar);
        }

        if (chatButton != null)
        {
            chatButton.GetComponent<UnityEngine.UI.Button>().onClick.AddListener(OpenChat);
        }
    }

    public void OpenSettings()
    {
        Debug.Log("Opening Settings scene");
        SceneManager.LoadScene("SettingsTab");
    }

    public void OpenPomodoroSettings()
    {
        Debug.Log("Opening PomodoroSettings scene");
        SceneManager.LoadScene("PomodoroSettings");
    }

    public void OpenCalendar()
    {
        Debug.Log("Opening Calendar scene");
        SceneManager.LoadScene("Calendar");
    }

    public void OpenChat()
    {
        Debug.Log("Opening Chat scene");
        SceneManager.LoadScene("Chat");
    }
}