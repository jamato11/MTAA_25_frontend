public static class SelectedChat
{
    public static int chatId;
}
