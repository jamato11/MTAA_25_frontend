using TMPro;
using UnityEngine;

public class ChatTile : MonoBehaviour
{
    public TextMeshProUGUI chatNameText;

    public void SetChatName(string name)
    {
        if (chatNameText != null)
            chatNameText.text = name;
        else
            Debug.LogError("chatNameText nie je nastavený v inšpektore!");
    }
}
