using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using System.Collections.Generic;
using UnityEngine.UI;
using System.IO;

[System.Serializable]
public class Message
{
    public int message_id;
    public int sender_user_id;
    public string sender_name;
    public string message_type;
    public string content;
    public string file_name;
    public string file_mimetype;
}

[System.Serializable]
public class MessageListResponse
{
    public Message[] messages;
}

public class ChatMessageLoader : MonoBehaviour
{
    public Transform messageContainer;
    public GameObject messageTilePrefab;

    private int chatId;
    private string apiUrl = "http://localhost:5000/chats/";
    private string fileApiUrl = "http://localhost:5000/messages/"; 
    private List<GameObject> spawnedTiles = new List<GameObject>();
    void Start()
    {
        if (SelectedChat.chatId > 0)
        {
            chatId = SelectedChat.chatId;
            LoadInitialMessages(chatId);
        }
        else
        {
            Debug.LogError("SelectedChat.chatId nie je nastavený.");
        }
    }

    public void LoadInitialMessages(int chatId)
    {
        this.chatId = chatId;
        StartCoroutine(LoadMessagesCoroutine(chatId));
    }

    public IEnumerator LoadMessagesCoroutine(int chatId)
    {
        string url = apiUrl + chatId + "/messages";

        using (UnityWebRequest request = UnityWebRequest.Get(url))
        {
            request.SetRequestHeader("Accept", "application/json");

            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError($"Chyba načítania správ pre chat ID {chatId}: " + request.error);
                yield break;
            }

            string json = request.downloadHandler.text;

            try
            {
                MessageListResponse response = JsonUtility.FromJson<MessageListResponse>(json);

                foreach (GameObject tile in spawnedTiles)
                {
                    Destroy(tile);
                }
                spawnedTiles.Clear();

                if (response != null && response.messages != null)
                {
                    foreach (Message msg in response.messages)
                    {
                        GameObject tile = Instantiate(messageTilePrefab, messageContainer);
                        spawnedTiles.Add(tile);

                        string text;
                        bool isFile = msg.message_type == "file";

                        if (isFile)
                        {
                            text = $"<b>{msg.sender_name} poslal súbor:</b>\n<color=#888>{msg.file_name}</color>\n({msg.file_mimetype})";
                        }
                        else
                        {
                            text = $"<b>{msg.sender_name}:</b> {msg.content}";
                        }

                        TMP_Text messageText = tile.transform.GetChild(0).GetComponent<TMP_Text>();
                        if (messageText != null)
                        {
                            messageText.text = text;
                        }

                        Button downloadButton = tile.transform.Find("DownloadButton")?.GetComponent<Button>();
                        if (downloadButton != null)
                        {
                            if (isFile)
                            {
                                downloadButton.gameObject.SetActive(true);
                                int messageId = msg.message_id;
                                string fileName = msg.file_name;
                                downloadButton.onClick.AddListener(() =>
                                {
                                    StartCoroutine(DownloadFileCoroutine(messageId, fileName));
                                });
                            }
                            else
                            {
                                downloadButton.gameObject.SetActive(false);
                            }
                        }
                    }

                    Canvas.ForceUpdateCanvases();
                    ScrollRect scrollRect = GetComponentInParent<ScrollRect>();
                    if (scrollRect != null)
                    {
                        scrollRect.verticalNormalizedPosition = 0f;
                    }
                }
                else
                {
                    Debug.LogWarning($"Žiadne správy pre chat ID {chatId}.");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Chyba pri spracovaní JSON odpovede: {e.Message}");
                Debug.LogError($"JSON String: {json}");
            }
        }
    }

    private IEnumerator DownloadFileCoroutine(int messageId, string fileName)
    {
        string url = fileApiUrl + messageId + "/file";
        using (UnityWebRequest www = UnityWebRequest.Get(url))
        {
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                byte[] fileData = www.downloadHandler.data;
                string path = Path.Combine(Application.persistentDataPath, fileName);
                File.WriteAllBytes(path, fileData);

                Debug.Log($"Súbor uložený do: {path}");
            }
            else
            {
                Debug.LogError("Chyba pri sťahovaní súboru: " + www.error);
            }
        }
    }

    public void ReloadMessages()
    {
        if (chatId > 0)
        {
            StartCoroutine(LoadMessagesCoroutine(chatId));
        }
        else
        {
            Debug.LogError("Chat ID nie je nastavené.");
        }
    }
}
