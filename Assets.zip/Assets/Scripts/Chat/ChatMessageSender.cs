/*using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using TMPro;
using NativeFilePickerNamespace;
using NativeWebSocket;
using System.Threading.Tasks; // Potrebné pre Task

[Serializable]
public class MessageResponseData
{
    public int message_id;
    public int sender_user_id;
    public int recipient_chat_id;
    public string content;
}

[Serializable]
public class MessageResponse
{
    public string message;
    public MessageResponseData data;
}

[Serializable]
public class WebSocketMessage
{
    public int sender_user_id;
    public int recipient_chat_id;
    public string message_type;
    public string content;
}

public class ChatMessageSender : MonoBehaviour
{
    public TMP_InputField messageInputField;
    public Button sendTextButton;
    public Button sendPngButton;
    public Button sendPdfButton;

    private int chatId;
    private int senderUserId;
    private string apiUrl = "http://localhost:5000/messages";
    private WebSocket webSocket;
    private string websocketUrl = "ws://localhost:5000"; 

    private async void Start()
    {
        chatId = SelectedChat.chatId;
        senderUserId = UserSession.userId;

        if (chatId <= 0 || senderUserId <= 0)
        {
            Debug.LogError($"Neplatné chat_id alebo user_id: chatId = {chatId}, senderUserId = {senderUserId}");
            return;
        }

        sendTextButton.onClick.AddListener(SendTextMessage);
        sendPngButton.onClick.AddListener(() => PickAndSendFile("image/png"));
        sendPdfButton.onClick.AddListener(() => PickAndSendFile("application/pdf"));

        // Inicializácia WebSocketu
        webSocket = new WebSocket(websocketUrl);

        webSocket.OnOpen += () =>
        {
            Debug.Log("Pripojené k WebSocket serveru.");
        };

        webSocket.OnMessage += (bytes) =>
        {
            var message = System.Text.Encoding.UTF8.GetString(bytes);
            Debug.Log("Prijatá správa cez WebSocket: " + message);

            // Deserialize JSON správu pomocou JsonUtility
            try
            {
                WebSocketMessage receivedMessage = JsonUtility.FromJson<WebSocketMessage>(message);
                if (receivedMessage != null && receivedMessage.recipient_chat_id == chatId)
                {
                    // Načítaj nové správy
                    ChatMessageLoader loader = FindObjectOfType<ChatMessageLoader>();
                    if (loader != null)
                    {
                        loader.ReloadMessages();

                    }

                    // Posuň scroll view na najnovšiu správu
                    ScrollRect scrollRect = FindObjectOfType<ScrollRect>();
                    if (scrollRect != null)
                    {
                        Canvas.ForceUpdateCanvases();
                        scrollRect.verticalNormalizedPosition = 0f;
                    }
                }
                else
                {
                    Debug.LogWarning("Prijatá WebSocket správa nie je pre tento chat.");
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("Chyba pri parsovaní JSON správy z WebSocketu: " + ex.Message);
                Debug.LogError("JSON String: " + message);
            }
        };

        webSocket.OnError += (e) =>
        {
            Debug.LogError("WebSocket chyba: " + e);
        };

        webSocket.OnClose += (code) =>
        {
            Debug.Log("WebSocket spojenie ukončené s kódom: " + code);
        };

        // Pokúsime sa pripojiť
        await webSocket.Connect();
    }

    private void Update()
    {
        #if !UNITY_WEBGL || UNITY_EDITOR
        webSocket.DispatchMessageQueue();
        #endif
    }

    private async void OnApplicationQuit()
    {
        if (webSocket != null && webSocket.State == WebSocketState.Open)
        {
            await webSocket.Close();
        }
    }

    public void SendTextMessage()
    {
        string content = messageInputField.text.Trim();
        if (string.IsNullOrEmpty(content))
        {
            Debug.LogWarning("Správa je prázdna.");
            return;
        }

        StartCoroutine(SendMessageCoroutine(content, null, null, null));
    }

    void PickAndSendFile(string mimeType)
    {
        string[] allowedTypes = mimeType == "image/png" ? new[] { "image/png" } : new[] { "application/pdf" };

        NativeFilePicker.PickFile((path) =>
        {
            if (string.IsNullOrEmpty(path))
            {
                Debug.Log("Výber súboru zrušený alebo povolenie zamietnuté.");
                return;
            }

            try
            {
                byte[] fileBytes = File.ReadAllBytes(path);
                string fileName = Path.GetFileName(path);
                StartCoroutine(SendMessageCoroutine(null, fileBytes, fileName, mimeType));
            }
            catch (System.Exception ex)
            {
                Debug.LogError("Chyba pri načítaní súboru: " + ex.Message);
            }
        }, allowedTypes);
    }

    private IEnumerator SendMessageCoroutine(string content, byte[] fileBytes, string fileName, string mimeType)
    {
        WWWForm form = new WWWForm();
        form.AddField("sender_user_id", senderUserId);
        form.AddField("recipient_chat_id", chatId);

        if (fileBytes != null)
        {
            form.AddField("message_type", "file");
            form.AddBinaryData("file", fileBytes, fileName, mimeType);
        }
        else
        {
            form.AddField("message_type", "text");
            form.AddField("content", content);
        }

        using (UnityWebRequest www = UnityWebRequest.Post(apiUrl, form))
        {
            www.SetRequestHeader("Accept", "application/json");

            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("Správa odoslaná a uložená do DB: " + www.downloadHandler.text);
                messageInputField.text = "";

                try
                {
                    MessageResponse response = JsonUtility.FromJson<MessageResponse>(www.downloadHandler.text);
                    if (response != null && response.data != null)
                    {
                        Debug.Log($"Server odpovedal - ID správy: {response.data.message_id}, obsah: {response.data.content}");
                    }
                    else
                    {
                        Debug.LogError("Nepodarilo sa parsovať odpoveď servera.");
                        Debug.LogError("Odpoveď servera: " + www.downloadHandler.text);
                    }
                }
                catch (Exception e)
                {
                    Debug.LogError("Chyba pri parsovaní JSON odpovede: " + e.Message);
                    Debug.LogError("JSON String: " + www.downloadHandler.text);
                }

                // Príprava payloadu pre WebSocket
                WebSocketMessage messagePayload = new WebSocketMessage
                {
                    sender_user_id = senderUserId,
                    recipient_chat_id = chatId,
                    message_type = fileBytes != null ? "file" : "text",
                    content = fileBytes != null ? "[SÚBOR ODOSLANÝ]" : content
                };

                string jsonPayload = JsonUtility.ToJson(messagePayload);

                SendWebSocketMessageAsync(jsonPayload);
            }
            else
            {
                Debug.LogError($"Chyba pri odosielaní správy ({www.responseCode}): {www.error}");
                Debug.LogError("Odpoveď servera: " + www.downloadHandler.text);
            }
        }
    }

    private async Task SendWebSocketMessageAsync(string payload)
    {
        if (webSocket != null && webSocket.State == WebSocketState.Open)
        {
            await webSocket.SendText(payload);
        }
        else
        {
            Debug.LogError("WebSocket nie je pripojený, správu nebolo možné odoslať.");
        }
    }
}*/