using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using System.Collections;

public class DeleteChat : MonoBehaviour
{
    private string baseUrl = "http://localhost:5000"; 

    public void OnDeleteChatButtonClicked()
    {
        int chatId = PlayerPrefs.GetInt("selected_chat_id", -1);

        if (chatId == -1)
        {
            Debug.LogError("Chyba: chat_id nebol nájdený v PlayerPrefs.");
            return;
        }
        StartCoroutine(DeleteChatRequest(chatId));
    }

    IEnumerator DeleteChatRequest(int chatId)
    {
        string url = $"{baseUrl}/chats/{chatId}";
        UnityWebRequest request = UnityWebRequest.Delete(url);

        yield return request.SendWebRequest();

#if UNITY_2020_1_OR_NEWER
        if (request.result == UnityWebRequest.Result.ConnectionError || request.result == UnityWebRequest.Result.ProtocolError)
#else
        if (request.isNetworkError || request.isHttpError)
#endif
        {
            Debug.LogError($"Chyba pri mazaní chatu: {request.error}");
        }
        else
        {
            Debug.Log("Chat úspešne odstránený.");
            SceneManager.LoadScene("Chat"); 
        }
    }
}
