using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;

[Serializable]
public class ChatData
{
    public int chat_id;
    public string chat_name;
}

[Serializable]
public class ChatsResponse
{
    public ChatData[] chats;
}

public class ChatListManager : MonoBehaviour
{
    public GameObject chatTilePrefab;
    public Transform chatListContent;
    public string backendUrl = "http://localhost:5000/users/";

    public static ChatListManager Instance;
    public delegate void OnChatSelected(int chatId);
    public static OnChatSelected ChatSelected;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        int userId = UserSession.userId != 0 ? UserSession.userId : 1; 
        GetChatsForUser(userId);
    }

    public void GetChatsForUser(int userId)
    {
        string url = backendUrl + userId + "/chats";
        StartCoroutine(SendRequestAndProcessResponse(UnityWebRequest.Get(url)));
    }

    IEnumerator SendRequestAndProcessResponse(UnityWebRequest request)
    {
        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Request failed: " + request.error);
            yield break;
        }

        string jsonResponse = request.downloadHandler.text;
        Debug.Log("Raw JSON: " + jsonResponse);

        try
        {
            ChatsResponse response = JsonUtility.FromJson<ChatsResponse>(jsonResponse);

            if (response == null || response.chats == null)
            {
                Debug.LogError("Parsed response or chats is null");
                yield break;
            }

            foreach (Transform child in chatListContent)
            {
                Destroy(child.gameObject);
            }

            foreach (ChatData chat in response.chats)
            {
                GameObject chatTile = Instantiate(chatTilePrefab, chatListContent);
                ChatTile chatTileScript = chatTile.GetComponent<ChatTile>();

                if (chatTileScript != null)
                    chatTileScript.SetChatName(chat.chat_name);
                else
                    Debug.LogError("ChatTile skript sa nenašiel na prefabe.");

                Button btn = chatTile.GetComponent<Button>();
                if (btn != null)
                {
                    int capturedId = chat.chat_id;
                    btn.onClick.AddListener(() =>
                    {
                        Debug.Log("Klikol si na chat s ID: " + capturedId);
                        SelectedChat.chatId = capturedId;
                        SceneManager.LoadScene("ChatViewer");
                    });
                }
                else
                    Debug.LogError("Button not found on prefab.");
            }
        }
        catch (Exception e)
        {
            Debug.LogError("Error processing JSON: " + e.Message);
            Debug.LogError("JSON String: " + jsonResponse);
        }
    }
}
