using UnityEngine;
using UnityEngine.SceneManagement;

public class ChatSceneManager : MonoBehaviour
{
    public GameObject ImageScroll;
    public GameObject FileScroll;
    
   void Start()
    {
        if (ImageScroll != null) ImageScroll.SetActive(false);
        if (FileScroll != null) FileScroll.SetActive(false);
    }

    public void GoToMainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void GoToChat()
    {
        SceneManager.LoadScene("Chat");
    }

    public void GoToCreateChat()
    {
        SceneManager.LoadScene("CreateChat");
    }

    public void GoToChatViewer()
    {
        SceneManager.LoadScene("ChatViewer");
    }

    public void GoToChatInfo()
    {
        SceneManager.LoadScene("ChatInfo");
    }

    public void GoToChatMembers()
    {
        SceneManager.LoadScene("ChatMembers");
    }

    public void GoToAddPeople()
    {
        SceneManager.LoadScene("AddPeople");
    }

    public void ShowImages()
    {
        ImageScroll.SetActive(true);
        FileScroll.SetActive(false);
    }

    public void ShowFiles()
    {
        ImageScroll.SetActive(false);
        FileScroll.SetActive(true);
    }
}

