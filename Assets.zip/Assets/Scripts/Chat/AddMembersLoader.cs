using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using UnityEngine.UI;
using MyApp.Models;

public class AddMembersLoader : MonoBehaviour
{
    public GameObject addMemberIconPrefab;
    public Transform contentContainer;

    private HashSet<int> currentMemberIds = new HashSet<int>();

    private void Start()
    {
        StartCoroutine(LoadUsersNotInChat());
    }

    IEnumerator LoadUsersNotInChat()
    {
        yield return StartCoroutine(GetCurrentMembers());

        string url = "http://localhost:5000/users";
        UnityWebRequest request = UnityWebRequest.Get(url);
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Chyba pri načítavaní používateľov: " + request.error);
            yield break;
        }

        string json = FixJson(request.downloadHandler.text);
        UserList userList = JsonUtility.FromJson<UserList>(json);

        foreach (User user in userList.users)
        {
            if (currentMemberIds.Contains(user.user_id)) continue;

            GameObject icon = Instantiate(addMemberIconPrefab, contentContainer);

            TextMeshProUGUI text = icon.GetComponentInChildren<TextMeshProUGUI>();
            if (text != null)
                text.text = user.name;

            Button addButton = icon.GetComponentInChildren<Button>();
            if (addButton != null)
            {
                int memberId = user.user_id;
                addButton.onClick.AddListener(() =>
                {
                    StartCoroutine(AddMemberToChat(memberId, addButton));
                });
            }
        }
    }

    IEnumerator GetCurrentMembers()
    {
        string url = $"http://localhost:5000/chats/{SelectedChat.chatId}/members";
        UnityWebRequest request = UnityWebRequest.Get(url);
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Chyba pri načítavaní členov chatu: " + request.error);
            yield break;
        }

        string json = FixJson(request.downloadHandler.text, true);
        MemberList memberList = JsonUtility.FromJson<MemberList>(json);

        foreach (Member member in memberList.members)
        {
            currentMemberIds.Add(member.user_id);
        }
    }

    IEnumerator AddMemberToChat(int memberId, Button button)
    {
        string url = $"http://localhost:5000/chats/{SelectedChat.chatId}/members";
        string jsonData = $"{{\"member_id\": {memberId}}}";
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);

        UnityWebRequest request = new UnityWebRequest(url, "POST");
        request.uploadHandler = new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("Používateľ pridaný.");
            TextMeshProUGUI btnText = button.GetComponentInChildren<TextMeshProUGUI>();
            if (btnText != null)
                btnText.text = "Added";

            button.interactable = false;
        }
        else if (request.responseCode == 409)
        {
            Debug.Log("Používateľ už je člen.");
        }
        else
        {
            Debug.LogError("Chyba pri pridávaní člena: " + request.error);
        }
    }

    private string FixJson(string json, bool isMemberList = false)
    {
        if (isMemberList && json.Contains("\"members\":"))
            return json.Replace("\"members\":", "\"members\":");

        if (!isMemberList && json.Contains("\"users\":"))
            return json.Replace("\"users\":", "\"users\":");

        return json;
    }
}
