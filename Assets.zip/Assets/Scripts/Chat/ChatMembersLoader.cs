using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using MyApp.Models;

public class ChatMembersLoader : MonoBehaviour
{
    public GameObject memberIconPrefab; 
    public Transform contentContainer;  

    private void Start()
    {
        if (SelectedChat.chatId != 0)
            StartCoroutine(LoadMembers(SelectedChat.chatId));
        else
            Debug.LogError("SelectedChat.chatId nie je nastavený.");
    }

    IEnumerator LoadMembers(int chatId)
    {
        string url = $"http://localhost:5000/chats/{chatId}/members";

        UnityWebRequest request = UnityWebRequest.Get(url);
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Chyba pri načítavaní členov: " + request.error);
            yield break;
        }

        Debug.Log("Stiahnutý JSON: " + request.downloadHandler.text);

        // Oprava JSON-u a odstránenie nadbytočných znakov
        string json = FixJson(request.downloadHandler.text);

        Debug.Log("Obalený JSON pre JsonUtility: " + json);

        // Deserializácia JSON-u
        MemberList memberList = JsonUtility.FromJson<MemberList>(json);

        // Načítanie členov do UI
        foreach (Member member in memberList.members)
        {
            GameObject icon = Instantiate(memberIconPrefab, contentContainer);
            TextMeshProUGUI text = icon.GetComponentInChildren<TextMeshProUGUI>();

            if (text != null)
                text.text = member.name;
            else
                Debug.LogWarning("TextMeshPro komponent sa nenašiel v prefabe.");
        }
    }

    private string FixJson(string rawJson)
    {
        int startIndex = rawJson.IndexOf("[");
        int endIndex = rawJson.LastIndexOf("]");

        if (startIndex == -1 || endIndex == -1 || endIndex <= startIndex)
        {
            Debug.LogError("Neplatný JSON formát.");
            return "{}"; 
        }

        // Vystrihneme iba obsah poľa
        string arrayContent = rawJson.Substring(startIndex, endIndex - startIndex + 1);
        string wrappedJson = $"{{\"members\":{arrayContent}}}";

        return wrappedJson;
    }
}
