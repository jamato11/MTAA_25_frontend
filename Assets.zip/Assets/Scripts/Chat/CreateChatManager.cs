using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using System.Collections;

public class CreateChatManager : MonoBehaviour
{
    [Header("UI References")]
    public TMP_InputField chatNameInput;
    public Button createChatButton;

    [Header("Backend")]
    public string apiUrl = "http://localhost:5000/chats";

    void Start()
    {
        if (createChatButton != null)
            createChatButton.onClick.AddListener(SendCreateChatRequest);
        else
            Debug.LogError("CreateChatButton nie je priradené v Inspector!");
    }

    void SendCreateChatRequest()
    {
        if (chatNameInput == null)
        {
            Debug.LogError("ChatNameInput (TMP_InputField) nie je priradené v Inspector!");
            return;
        }

        string chatName = chatNameInput.text;

        // Get user ID from UserSessionManager
        int userId = UserSessionManager.Instance != null ? UserSessionManager.Instance.GetCurrentUserId() : -1;

        if (string.IsNullOrEmpty(chatName))
        {
            Debug.LogWarning("Zadaj názov chatu!");
            return;
        }
        if (userId == -1)
        {
            Debug.LogWarning("Nie si prihlásený (user_id chýba)!");
            return;
        }

        StartCoroutine(PostNewChat(chatName, userId));
    }

    IEnumerator PostNewChat(string chatName, int userId)
    {
        string json = $"{{\"chat_name\":\"{chatName}\", \"creator_id\":{userId}}}";
        byte[] body = System.Text.Encoding.UTF8.GetBytes(json);

        var request = new UnityWebRequest(apiUrl, "POST")
        {
            uploadHandler = new UploadHandlerRaw(body),
            downloadHandler = new DownloadHandlerBuffer()
        };
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("Chat vytvorený: " + request.downloadHandler.text);
            SceneManager.LoadScene("Chat");
        }
        else
        {
            Debug.LogError("Chyba pri vytváraní chatu: " + request.error);
        }
    }
}
