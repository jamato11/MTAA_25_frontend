using System;
using System.Collections.Generic;

namespace MyApp.Models
{
    [Serializable]
    public class Member
    {
        public int user_id;
        public string name;
        public string email;
        public int membership_id;
    }

    [Serializable]
    public class MemberList
    {
        public Member[] members;
    }

    [Serializable]
    public class User
    {
        public int user_id;
        public string name;
        public string email;
    }

    [Serializable]
    public class UserList
    {
        public User[] users;
    }
}
