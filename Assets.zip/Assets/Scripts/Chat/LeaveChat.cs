using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;

public class LeaveChat : MonoBehaviour
{
    public Button leaveChatButton;

    private void Start()
    {
        leaveChatButton.onClick.AddListener(OnLeaveChat);
    }

    public void OnLeaveChat()
    {
        int chatId;
        int userId;

        if (UserSession.userId != 0)  
        {
            userId = UserSession.userId;
        }
        else
        {
            Debug.LogWarning("UserSession.userId nie je nastavený, použijem testovací userId = 1");
            userId = 1; 
        }

        if (SelectedChat.chatId != 0)
        {
            chatId = SelectedChat.chatId;
        }
        else
        {
            Debug.LogWarning("SelectedChat.chatId je 0, použijem testovací chatId = 2");
            chatId = 2; 
        }

        SelectedChat.chatId = chatId;
        UserSession.userId = userId;  // prístup priamo cez triedu, keďže je static

        StartCoroutine(GetMembershipIdAndRemoveMember(chatId, userId));
    }

    private IEnumerator GetMembershipIdAndRemoveMember(int chatId, int userId)
    {
        string url = $"http://localhost:5000/chats/memberships?chat_id={chatId}&user_id={userId}";

        UnityWebRequest request = UnityWebRequest.Get(url);
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("Získané membership_id: " + request.downloadHandler.text);

            string response = request.downloadHandler.text;
            int membershipId = ParseMembershipId(response);

            yield return StartCoroutine(RemoveMemberFromChat(membershipId));
        }
        else
        {
            Debug.LogError("Chyba pri získavaní membership_id: " + request.error);
        }
    }

    private int ParseMembershipId(string jsonResponse)
    {
        var data = JsonUtility.FromJson<MembershipResponse>(jsonResponse);
        return data.membership_id;
    }

    private IEnumerator RemoveMemberFromChat(int membershipId)
    {
        string url = $"http://localhost:5000/chats/members/{membershipId}";
        UnityWebRequest request = UnityWebRequest.Delete(url);

        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("Používateľ bol úspešne odstránený z chatu");

            SceneManager.LoadScene("Chat");
        }
        else
        {
            Debug.LogError("Chyba pri odstraňovaní používateľa z chatu: " + request.error);
        }
    }

    [System.Serializable]
    public class MembershipResponse
    {
        public int membership_id;
    }
}
