using UnityEngine;

public class UserSession : MonoBehaviour
{
    public static UserSession Instance;
    public static int userId;
    public string userName;
    public string userEmail;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); 
        }
        else
        {
            Destroy(gameObject); 
        }
    }
}
