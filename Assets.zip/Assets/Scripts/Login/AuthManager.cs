using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.Networking;
using System.Collections;
using System;
using UnityEngine.SceneManagement;
using System.Text;

[System.Serializable]
public class UserData
{
    public int user_id;
    public string name;
    public string email;
    public DateTime lastLogin;
}

[System.Serializable]
public class LoginRequest
{
    public string email;
    public string password;
}

[System.Serializable]
public class RegistrationRequest
{
    public string name;
    public string email;
    public string password;
}

[System.Serializable]
public class AuthResponse
{
    public bool success;
    public string message;
    public UserData user;
}

public class AuthManager : MonoBehaviour
{
    private const string USER_PREFS_KEY = "USER_DATA";
    private const string LAST_USER_KEY = "LAST_USER";
    private const float CONNECTION_TIMEOUT = 10f;

    [Header("Server Configuration")]
    [SerializeField] private string backendURL = "http://localhost:5000";

    [Header("UI Elements")]
    [SerializeField] private GameObject nameField;
    [SerializeField] private TMP_InputField nameInput;
    [SerializeField] private TMP_InputField emailInput;
    [SerializeField] private TMP_InputField passwordInput;
    [SerializeField] private Button loginButton;
    [SerializeField] private Button registerButton;
    [SerializeField] private TextMeshProUGUI loginTitleText;
    [SerializeField] private TextMeshProUGUI loginButtonText;
    [SerializeField] private TextMeshProUGUI registerButtonText;
    [SerializeField] private TextMeshProUGUI accountQuestion;
    [SerializeField] private TMP_Text infoText;

    private bool isRegisterMode = false;
    private bool isOnline = false;
    private static AuthManager _instance;

    private UserData _currentUser;

    public UserData CurrentUser
    {
        get { return _currentUser; }
        set { _currentUser = value; }
    }

    public bool IsLoggedIn
    {
        get { return _currentUser != null; }
    }

    public static AuthManager Instance
    {
        get { return _instance; }
    }

    private void Awake()
    {
        Debug.Log("AuthManager awakening...");
        _instance = this;
        LoadUserData();
    }

    private void Start()
    {
        Debug.Log("AuthManager started");
        SetupUI();
        StartCoroutine(CheckInternetConnection());
    }

    private void SetupUI()
    {
        if (nameField != null)
            nameField.SetActive(false);

        if (registerButton != null)
        {
            registerButton.onClick.RemoveAllListeners();
            registerButton.onClick.AddListener(OnRegisterButtonClicked);
        }

        if (loginButton != null)
        {
            loginButton.onClick.RemoveAllListeners();
            loginButton.onClick.AddListener(OnLoginButtonClicked);
        }

        if (infoText != null)
            infoText.text = "";

        if (IsLoggedIn)
        {
            SetInfoText($"Welcome back, {CurrentUser.name}!", Color.green);
        }
    }

    private IEnumerator CheckInternetConnection()
    {
        const float checkInterval = 5f;
        WaitForSeconds wait = new WaitForSeconds(checkInterval);

        while (true)
        {
            using (UnityWebRequest request = UnityWebRequest.Get("https://www.google.com"))
            {
                request.timeout = 5;
                yield return request.SendWebRequest();

                bool wasOnline = isOnline;
                isOnline = request.result != UnityWebRequest.Result.ConnectionError &&
                           request.result != UnityWebRequest.Result.DataProcessingError;

                if (wasOnline != isOnline)
                {
                    Debug.Log($"Connection status changed: {(isOnline ? "Online" : "Offline")}");

                    if (!isOnline)
                    {
                        SetInfoText("You are currently offline. Some features may be limited.", new Color(1f, 0.6f, 0f)); // Orange
                    }
                    else if (infoText.text.Contains("offline"))
                    {
                        SetInfoText("Connection restored!", Color.green);
                        yield return new WaitForSeconds(2f);
                        infoText.text = "";
                    }
                }
            }

            yield return wait;
        }
    }

    public void OnRegisterButtonClicked()
    {
        SetRegisterMode(!isRegisterMode);
    }

    public void OnLoginButtonClicked()
    {
        if (isRegisterMode)
        {
            AttemptRegister();
        }
        else
        {
            AttemptLogin();
        }
    }

    private void SetRegisterMode(bool isRegister)
    {
        isRegisterMode = isRegister;
        infoText.text = "";

        if (nameField != null)
            nameField.SetActive(isRegister);

        if (loginTitleText != null)
            loginTitleText.text = isRegister ? "REGISTER" : "LOGIN";

        if (loginButtonText != null)
            loginButtonText.text = isRegister ? "Register" : "Login";

        if (registerButtonText != null)
            registerButtonText.text = isRegister ? "Login" : "Register";

        if (accountQuestion != null)
            accountQuestion.text = isRegister ? "Already have an account?" : "Don't have an account?";
    }

    public void AttemptRegister()
    {
        if (!ValidateRegistrationInput())
            return;

        if (!isOnline)
        {
            SetInfoText("Cannot register while offline. Please check your internet connection.", Color.red);
            return;
        }

        string name = nameInput.text.Trim();
        string email = emailInput.text.Trim();
        string password = passwordInput.text;

        RegistrationRequest jsonRequest = new RegistrationRequest
        {
            name = name,
            email = email,
            password = password
        };

        string jsonData = JsonUtility.ToJson(jsonRequest);
        SetLoadingState(true);

        StartCoroutine(PostJSONRequest(backendURL + "/register", jsonData, HandleRegisterResponse));
    }

    private bool ValidateRegistrationInput()
    {
        if (nameInput == null || string.IsNullOrWhiteSpace(nameInput.text))
        {
            SetInfoText("Please enter your name.", Color.red);
            return false;
        }

        if (emailInput == null || string.IsNullOrWhiteSpace(emailInput.text))
        {
            SetInfoText("Please enter your email address.", Color.red);
            return false;
        }

        if (!IsValidEmail(emailInput.text))
        {
            SetInfoText("Please enter a valid email address.", Color.red);
            return false;
        }

        if (passwordInput == null || string.IsNullOrEmpty(passwordInput.text))
        {
            SetInfoText("Please enter a password.", Color.red);
            return false;
        }

        if (passwordInput.text.Length < 6)
        {
            SetInfoText("Password must be at least 6 characters long.", Color.red);
            return false;
        }

        return true;
    }

    private bool IsValidEmail(string email)
    {
        try
        {
            var addr = new System.Net.Mail.MailAddress(email);
            return addr.Address == email;
        }
        catch
        {
            return false;
        }
    }

    private void HandleRegisterResponse(string result, UnityWebRequest.Result requestResult)
    {
        SetLoadingState(false);

        if (requestResult != UnityWebRequest.Result.Success)
        {
            if (requestResult == UnityWebRequest.Result.ConnectionError)
            {
                SetInfoText("Registration failed: Could not connect to server.", Color.red);
            }
            else
            {
                SetInfoText("Registration failed. Please try again later.", Color.red);
            }
            return;
        }

        if (string.IsNullOrEmpty(result))
        {
            SetInfoText("Registration error: No response from server.", Color.red);
            return;
        }

        try
        {
            AuthResponse response = JsonUtility.FromJson<AuthResponse>(result);
            if (response != null && response.message.Contains("Úspešne registrovaný používateľ"))
            {
                SetInfoText("Registration successful! You can now log in.", Color.green);
                SetRegisterMode(false);

                if (emailInput != null)
                {
                    emailInput.text = response.user.email;
                }

                if (passwordInput != null)
                {
                    passwordInput.text = "";
                }

                Debug.Log("Registration successful: " + result);
            }
            else if (response != null && !string.IsNullOrEmpty(response.message))
            {
                SetInfoText("Registration error: " + response.message, Color.red);
            }
            else
            {
                SetInfoText("Registration error: Unknown response format.", Color.red);
                Debug.LogError("Unexpected server response during registration: " + result);
            }
        }
        catch (Exception e)
        {
            SetInfoText("Error processing registration response.", Color.red);
            Debug.LogError("Error parsing JSON response during registration: " + e.Message + "\nResponse: " + result);
        }
    }

    public void AttemptLogin()
    {
        if (!ValidateLoginInput())
            return;

        string email = emailInput.text.Trim();
        string password = passwordInput.text;

        if (!isOnline)
        {
            SetInfoText("Attempting offline login...", new Color(1f, 0.6f, 0f));
            if (TryOfflineLogin(email, password))
            {
                OnLoginSuccess(CurrentUser);
            }
            else
            {
                SetInfoText("Offline login failed. Please check your credentials or connect to the internet.", Color.red);
            }
            return;
        }

        LoginRequest jsonRequest = new LoginRequest
        {
            email = email,
            password = password
        };

        string jsonData = JsonUtility.ToJson(jsonRequest);
        SetLoadingState(true);

        Debug.Log("Attempting login to: " + backendURL + "/login");
        StartCoroutine(PostJSONRequest(backendURL + "/login", jsonData, HandleLoginResponse));
    }

    private bool ValidateLoginInput()
    {
        if (emailInput == null || string.IsNullOrWhiteSpace(emailInput.text))
        {
            SetInfoText("Please enter your email address.", Color.red);
            return false;
        }

        if (passwordInput == null || string.IsNullOrEmpty(passwordInput.text))
        {
            SetInfoText("Please enter your password.", Color.red);
            return false;
        }

        return true;
    }

    private void HandleLoginResponse(string result, UnityWebRequest.Result requestResult)
    {
        SetLoadingState(false);

        if (requestResult != UnityWebRequest.Result.Success)
        {
            if (requestResult == UnityWebRequest.Result.ConnectionError)
            {
                SetInfoText("Login failed: Could not connect to server.", Color.red);
            }
            else
            {
                SetInfoText("Login failed. Please try again later.", Color.red);
            }
            return;
        }

        if (string.IsNullOrEmpty(result))
        {
            SetInfoText("Login error: No response from server.", Color.red);
            return;
        }

        try
        {
            AuthResponse response = JsonUtility.FromJson<AuthResponse>(result);
            if (response != null && response.message.Contains("Úspešné prihlásenie") && response.user != null)
            {
                CurrentUser = response.user;
                CurrentUser.lastLogin = DateTime.Now;
                SaveUserData();

                OnLoginSuccess(CurrentUser);
            }
            else if (response != null && !string.IsNullOrEmpty(response.message))
            {
                SetInfoText("Login error: " + response.message, Color.red);
            }
            else
            {
                SetInfoText("Login error: Unknown response format.", Color.red);
                Debug.LogError("Unexpected server response during login: " + result);
            }
        }
        catch (Exception e)
        {
            SetInfoText("Error processing login response.", Color.red);
            Debug.LogError("Error parsing JSON response during login: " + e.Message + "\nResponse: " + result);
        }
    }

    private bool TryOfflineLogin(string email, string password)
    {
        if (CurrentUser != null && CurrentUser.email.Equals(email, StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        return false;
    }

    private void OnLoginSuccess(UserData user)
    {
        SetInfoText("Login successful! Welcome, " + user.name, Color.green);
        Debug.Log("Login successful for user: " + user.name);

        SetLastLoggedInUser(user);

        StartCoroutine(DelayedSceneLoad("MainMenu", 1.0f));
    }

    public void SetLastLoggedInUser(UserData user)
    {
        if (user != null)
        {
            string userData = JsonUtility.ToJson(user);
            PlayerPrefs.SetString(LAST_USER_KEY, userData);
            PlayerPrefs.Save();
            Debug.Log($"Last logged in user set to: {user.name}");
        }
    }

    public static UserData GetLastLoggedInUser()
    {
        if (PlayerPrefs.HasKey(LAST_USER_KEY))
        {
            string userData = PlayerPrefs.GetString(LAST_USER_KEY);
            try
            {
                return JsonUtility.FromJson<UserData>(userData);
            }
            catch (Exception e)
            {
                Debug.LogError($"Error loading last user data: {e.Message}");
                return null;
            }
        }
        return null;
    }

    private IEnumerator DelayedSceneLoad(string sceneName, float delay)
    {
        yield return new WaitForSeconds(delay);
        SceneManager.LoadScene(sceneName);
    }

    public void Logout()
    {
        CurrentUser = null;
        PlayerPrefs.DeleteKey(USER_PREFS_KEY);
        PlayerPrefs.Save();

        SceneManager.LoadScene("Login");
    }

    private IEnumerator PostJSONRequest(string url, string jsonData, Action<string, UnityWebRequest.Result> callback)
    {
        using (UnityWebRequest www = new UnityWebRequest(url, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(jsonData);
            www.uploadHandler = new UploadHandlerRaw(bodyRaw);
            www.downloadHandler = new DownloadHandlerBuffer();
            www.SetRequestHeader("Content-Type", "application/json");
            www.timeout = Mathf.RoundToInt(CONNECTION_TIMEOUT);

            float startTime = Time.time;
            bool timeoutMessageShown = false;

            UnityWebRequestAsyncOperation operation = www.SendWebRequest();

            while (!operation.isDone)
            {
                if (Time.time - startTime > CONNECTION_TIMEOUT * 0.7f && !timeoutMessageShown)
                {
                    SetInfoText("Connection is taking longer than expected...", new Color(1f, 0.6f, 0f));
                    timeoutMessageShown = true;
                }
                yield return null;
            }

            callback(www.downloadHandler.text, www.result);
        }
    }

    private void SetInfoText(string message, Color color)
    {
        if (infoText != null)
        {
            infoText.text = message;
            infoText.color = color;
        }

        Debug.Log(message);
    }

    private void SetLoadingState(bool isLoading)
    {
        if (loginButton != null)
            loginButton.interactable = !isLoading;

        if (registerButton != null)
            registerButton.interactable = !isLoading;

        if (isLoading && infoText != null)
            SetInfoText("Processing...", Color.yellow);
    }

    private void SaveUserData()
    {
        if (CurrentUser != null)
        {
            string userData = JsonUtility.ToJson(CurrentUser);
            PlayerPrefs.SetString(USER_PREFS_KEY, userData);
            PlayerPrefs.Save();
        }
    }

    private void LoadUserData()
    {
        if (PlayerPrefs.HasKey(USER_PREFS_KEY))
        {
            string userData = PlayerPrefs.GetString(USER_PREFS_KEY);
            try
            {
                CurrentUser = JsonUtility.FromJson<UserData>(userData);
                Debug.Log($"Loaded user data for: {CurrentUser.name}");
            }
            catch (Exception e)
            {
                Debug.LogError($"Error loading user data: {e.Message}");
                CurrentUser = null;
            }
        }
    }
}