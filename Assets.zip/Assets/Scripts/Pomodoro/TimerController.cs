using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class TimerController : MonoBehaviour
{
    [Header("UI Elements")]
    [SerializeField] private TextMeshProUGUI timerText;
    [SerializeField] private TextMeshProUGUI statusText;
    [SerializeField] private Button pauseButton;
    [SerializeField] private Button resetButton;
    [SerializeField] private Button stopButton;
    [SerializeField] private Button backButton; // Added back button

    // The TimerController now uses PomodoroManager's PomodoriInCurrentCycle instead of tracking locally

    private void Start()
    {
        if (!PomodoroManager.Instance.AreSettingsValid())
        {
            SceneManager.LoadScene("PomodoroSettings");
            return;
        }

        PomodoroManager.Instance.OnTimerTick += UpdateTimerDisplay;
        PomodoroManager.Instance.OnTimerComplete += OnTimerComplete;

        pauseButton.onClick.AddListener(TogglePause);
        resetButton.onClick.AddListener(ResetTimer);
        stopButton.onClick.AddListener(StopTimer);

        // Add listener for the back button
        if (backButton != null)
        {
            backButton.onClick.AddListener(ReturnToMainMenu);
        }

        StartFocusSession();
    }

    private void OnDestroy()
    {
        // Only unsubscribe if the application is actually quitting
        // This prevents issues when navigating between scenes
        if (PomodoroManager.Instance != null && PomodoroManager.Instance.IsApplicationQuitting)
        {
            PomodoroManager.Instance.OnTimerTick -= UpdateTimerDisplay;
            PomodoroManager.Instance.OnTimerComplete -= OnTimerComplete;
        }
    }

    private void UpdateTimerDisplay(float remainingSeconds)
    {
        timerText.text = PomodoroManager.Instance.GetFormattedTime();
    }

    private void OnTimerComplete()
    {
        // Play a sound or show a notification that the timer is complete
        statusText.text = "TIME IS UP!";

        // Automatically advance to the next stage of the Pomodoro cycle
        switch (PomodoroManager.Instance.CurrentState)
        {
            case PomodoroManager.PomodoroState.Focus:
                // Check if it's time for a long break
                if (PomodoroManager.Instance.ShouldTakeLongBreak())
                {
                    // Start a long break
                    StartLongBreak();
                }
                else
                {
                    // Otherwise, take a short break
                    StartShortBreak();
                }
                break;

            case PomodoroManager.PomodoroState.ShortBreak:
            case PomodoroManager.PomodoroState.LongBreak:
                // After any break, start a focus session
                StartFocusSession();
                break;
        }
    }

    private void StartFocusSession()
    {
        PomodoroManager.Instance.StartTimer(PomodoroManager.PomodoroState.Focus);
        statusText.text = "Focus Time";
    }

    private void StartShortBreak()
    {
        PomodoroManager.Instance.StartTimer(PomodoroManager.PomodoroState.ShortBreak);
        statusText.text = "Short Break";
    }

    private void StartLongBreak()
    {
        PomodoroManager.Instance.StartTimer(PomodoroManager.PomodoroState.LongBreak);
        statusText.text = "Long Break";
    }

    private void TogglePause()
    {
        if (PomodoroManager.Instance.IsRunning)
        {
            PomodoroManager.Instance.PauseTimer();
            pauseButton.GetComponentInChildren<TextMeshProUGUI>().text = "Resume Timer";
        }
        else
        {
            PomodoroManager.Instance.ResumeTimer();
            pauseButton.GetComponentInChildren<TextMeshProUGUI>().text = "Pause Timer";
        }
    }

    private void ResetTimer()
    {
        PomodoroManager.Instance.ResetTimer();

        switch (PomodoroManager.Instance.CurrentState)
        {
            case PomodoroManager.PomodoroState.Focus:
                StartFocusSession();
                break;
            case PomodoroManager.PomodoroState.ShortBreak:
                StartShortBreak();
                break;
            case PomodoroManager.PomodoroState.LongBreak:
                StartLongBreak();
                break;
        }
    }

    private void StopTimer()
    {
        PomodoroManager.Instance.StopTimer();
        SceneManager.LoadScene("PomodoroSettings");
    }

    private void ReturnToMainMenu()
    {
        // Don't stop the timer, keep it running in the background
        // The PomodoroManager will continue to track time and send notifications
        // since it's a singleton that persists between scenes

        // Load the main menu scene - replace "MainMenu" with your actual main menu scene name
        SceneManager.LoadScene("MainMenu");
    }
}