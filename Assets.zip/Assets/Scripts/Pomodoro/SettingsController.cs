using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class SettingsController : MonoBehaviour
{
    [Header("Input Fields")]
    [SerializeField] private TMP_InputField focusDurationInput;
    [SerializeField] private TMP_InputField shortBreakDurationInput;
    [SerializeField] private TMP_InputField longBreakDurationInput;

    [Header("Buttons")]
    [SerializeField] private Button startPomodoroButton;
    [SerializeField] private Button backMenuButton;

    private void Start()
    {
        focusDurationInput.onValueChanged.AddListener(ValidateInputs);
        shortBreakDurationInput.onValueChanged.AddListener(ValidateInputs);
        longBreakDurationInput.onValueChanged.AddListener(ValidateInputs);

        startPomodoroButton.onClick.AddListener(StartPomodoroCycle);
        backMenuButton.onClick.AddListener(BackToMenu);

        startPomodoroButton.interactable = false;
    }

    private void ValidateInputs(string _)
    {
        bool isValid = AreInputsValid();
        startPomodoroButton.interactable = isValid;
    }

    private bool AreInputsValid()
    {
        bool focusValid = !string.IsNullOrEmpty(focusDurationInput.text) &&
                         int.TryParse(focusDurationInput.text, out int focus) &&
                         focus > 0;

        bool shortBreakValid = !string.IsNullOrEmpty(shortBreakDurationInput.text) &&
                              int.TryParse(shortBreakDurationInput.text, out int shortBreak) &&
                              shortBreak > 0;

        bool longBreakValid = !string.IsNullOrEmpty(longBreakDurationInput.text) &&
                             int.TryParse(longBreakDurationInput.text, out int longBreak) &&
                             longBreak > 0;

        return focusValid && shortBreakValid && longBreakValid;
    }

    private void StartPomodoroCycle()
    {
        if (AreInputsValid())
        {
            PomodoroManager.Instance.FocusDurationMinutes = int.Parse(focusDurationInput.text);
            PomodoroManager.Instance.ShortBreakDurationMinutes = int.Parse(shortBreakDurationInput.text);
            PomodoroManager.Instance.LongBreakDurationMinutes = int.Parse(longBreakDurationInput.text);

            SceneManager.LoadScene("PomodoroTimer");
        }
    }

    private void BackToMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}