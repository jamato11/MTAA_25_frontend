using UnityEngine;
using System;
using Unity.Notifications.Android;
using UnityEngine.SceneManagement;

// This is a singleton class to manage Pomodoro data across scenes
public class PomodoroManager : MonoBehaviour
{
    public static PomodoroManager Instance { get; private set; }

    public int FocusDurationMinutes { get; set; }
    public int ShortBreakDurationMinutes { get; set; }
    public int LongBreakDurationMinutes { get; set; }
    public int LongBreakAfterPomodoros { get; set; } = 4; // Default to 4 focus sessions before long break

    public float RemainingSeconds { get; set; }
    public bool IsRunning { get; private set; }
    public PomodoroState CurrentState { get; private set; }
    public int CompletedPomodoros { get; private set; }
    public int PomodoriInCurrentCycle { get; private set; } // Track pomodoros in current cycle

    // Flag to track if the application is quitting
    private bool isApplicationQuitting = false;
    public bool IsApplicationQuitting => isApplicationQuitting;

    public event Action<float> OnTimerTick;
    public event Action OnTimerComplete;

    private const string CHANNEL_ID = "pomodoro_channel";
    private const string PREFS_STATS_KEY = "pomodoro_stats";

    public enum PomodoroState
    {
        Focus,
        ShortBreak,
        LongBreak
    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            SetupNotificationChannel();
            LoadStats();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        if (IsRunning)
        {
            RemainingSeconds -= Time.deltaTime;

            OnTimerTick?.Invoke(RemainingSeconds);

            if (RemainingSeconds <= 0)
            {
                CompleteTimer();
            }
        }
    }

    public void StartTimer(PomodoroState state)
    {
        CurrentState = state;

        switch (state)
        {
            case PomodoroState.Focus:
                RemainingSeconds = FocusDurationMinutes * 60;
                break;
            case PomodoroState.ShortBreak:
                RemainingSeconds = ShortBreakDurationMinutes * 60;
                break;
            case PomodoroState.LongBreak:
                RemainingSeconds = LongBreakDurationMinutes * 60;
                // Reset the cycle count after starting a long break
                PomodoriInCurrentCycle = 0;
                break;
        }

        IsRunning = true;
    }

    public void PauseTimer()
    {
        IsRunning = false;
    }

    public void ResumeTimer()
    {
        IsRunning = true;
    }

    public void ResetTimer()
    {
        IsRunning = false;

        // Reset the timer to the full duration for the current state
        switch (CurrentState)
        {
            case PomodoroState.Focus:
                RemainingSeconds = FocusDurationMinutes * 60;
                break;
            case PomodoroState.ShortBreak:
                RemainingSeconds = ShortBreakDurationMinutes * 60;
                break;
            case PomodoroState.LongBreak:
                RemainingSeconds = LongBreakDurationMinutes * 60;
                break;
        }
    }

    public void StopTimer()
    {
        IsRunning = false;
        RemainingSeconds = 0;
        SaveStats();
    }

    private void CompleteTimer()
    {
        IsRunning = false;

        if (CurrentState == PomodoroState.Focus)
        {
            CompletedPomodoros++;
            PomodoriInCurrentCycle++;

            SaveStats();

            // Determine notification message based on what's next
            string notificationMessage;
            if (PomodoriInCurrentCycle >= LongBreakAfterPomodoros)
            {
                notificationMessage = "Time for a long break!";
                // Automatically advance to long break if not in timer screen
                if (!IsActiveUIScene())
                {
                    CurrentState = PomodoroState.LongBreak;
                    RemainingSeconds = LongBreakDurationMinutes * 60;
                    IsRunning = true;
                }
            }
            else
            {
                notificationMessage = "Time for a short break!";
                // Automatically advance to short break if not in timer screen
                if (!IsActiveUIScene())
                {
                    CurrentState = PomodoroState.ShortBreak;
                    RemainingSeconds = ShortBreakDurationMinutes * 60;
                    IsRunning = true;
                }
            }

            ShowNotification("Focus session complete!", notificationMessage);
        }
        else
        {
            // After any break, automatically advance to focus session if not in timer screen
            if (!IsActiveUIScene())
            {
                CurrentState = PomodoroState.Focus;
                RemainingSeconds = FocusDurationMinutes * 60;
                IsRunning = true;

                // If it was a long break, reset the cycle counter
                if (CurrentState == PomodoroState.LongBreak)
                {
                    PomodoriInCurrentCycle = 0;
                }
            }

            ShowNotification("Break is over!", "Time to focus again.");
        }

        OnTimerComplete?.Invoke();
    }

    private void SetupNotificationChannel()
    {
        #if UNITY_ANDROID
        var channel = new AndroidNotificationChannel()
        {
            Id = CHANNEL_ID,
            Name = "Pomodoro Notifications",
            Importance = Importance.High,
            Description = "Notifications for Pomodoro Timer app"
        };

        AndroidNotificationCenter.RegisterNotificationChannel(channel);
        #endif
    }

    private void ShowNotification(string title, string text)
    {
        #if UNITY_ANDROID
        var notification = new AndroidNotification
        {
            Title = title,
            Text = text,
            SmallIcon = "icon_small",
            LargeIcon = "icon_large",
            FireTime = DateTime.Now
        };

        AndroidNotificationCenter.SendNotification(notification, CHANNEL_ID);
        #elif UNITY_IOS
        // Add iOS notification code here if needed
        #else
        Debug.Log($"Notification: {title} - {text}");
        #endif
    }

    public bool AreSettingsValid()
    {
        return FocusDurationMinutes > 0 && ShortBreakDurationMinutes > 0 && LongBreakDurationMinutes > 0;
    }

    public string GetFormattedTime()
    {
        int minutes = Mathf.FloorToInt(RemainingSeconds / 60);
        int seconds = Mathf.FloorToInt(RemainingSeconds % 60);
        return string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    public bool ShouldTakeLongBreak()
    {
        return PomodoriInCurrentCycle >= LongBreakAfterPomodoros;
    }

    private void SaveStats()
    {
        PlayerPrefs.SetInt(PREFS_STATS_KEY, CompletedPomodoros);
        PlayerPrefs.Save();
    }

    private void LoadStats()
    {
        CompletedPomodoros = PlayerPrefs.GetInt(PREFS_STATS_KEY, 0);
    }

    private void OnApplicationQuit()
    {
        isApplicationQuitting = true;
        SaveStats();
    }

    private void OnApplicationPause(bool pauseStatus)
    {
        // If application is paused (going to background), save the current state
        if (pauseStatus)
        {
            SaveTimer();
        }
        // If application is resumed, check if we need to update the timer
        else
        {
            LoadTimer();
        }
    }

    private void SaveTimer()
    {
        if (IsRunning)
        {
            // Save the timestamp when we paused
            PlayerPrefs.SetString("timer_pause_time", DateTime.Now.ToString("o"));
            PlayerPrefs.SetFloat("timer_remaining", RemainingSeconds);
            PlayerPrefs.SetInt("timer_state", (int)CurrentState);
            PlayerPrefs.SetInt("timer_running", IsRunning ? 1 : 0);
            PlayerPrefs.Save();
        }
    }

    private void LoadTimer()
    {
        if (PlayerPrefs.HasKey("timer_pause_time") && PlayerPrefs.GetInt("timer_running", 0) == 1)
        {
            // Calculate elapsed time since the app was paused
            DateTime pauseTime = DateTime.Parse(PlayerPrefs.GetString("timer_pause_time"));
            TimeSpan elapsed = DateTime.Now - pauseTime;

            // Update remaining time
            float savedRemaining = PlayerPrefs.GetFloat("timer_remaining", 0);
            RemainingSeconds = Mathf.Max(0, savedRemaining - (float)elapsed.TotalSeconds);

            // Restore timer state
            CurrentState = (PomodoroState)PlayerPrefs.GetInt("timer_state", 0);
            IsRunning = RemainingSeconds > 0;

            // If timer should have finished while app was in background, handle it
            if (RemainingSeconds <= 0 && savedRemaining > 0)
            {
                CompleteTimer();
            }
        }
    }

    // Helper method to check if we're in a scene with UI controls for the timer
    private bool IsActiveUIScene()
    {
        string currentScene = SceneManager.GetActiveScene().name;
        // Replace "PomodoroTimer" with your actual timer scene name
        return currentScene == "PomodoroTimer";
    }
}