using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class CalendarManager : MonoBehaviour
{
    [Header("Calendar UI")]
    [SerializeField] private GameObject calendarPanel;
    [SerializeField] private TextMeshProUGUI monthText;
    [SerializeField] private Button previousButton;
    [SerializeField] private Button nextButton;
    [SerializeField] private GameObject dateButtonPrefab;
    [SerializeField] private Transform datesParent;
    [SerializeField] private Button backButton;
    [SerializeField] private Button addButton;

    [Header("Scene Loading")]
    [SerializeField] private string tasksSceneName = "Tasks";
    [SerializeField] private bool useCustomSceneNames = false;
    [SerializeField] private List<CustomDateScene> customDateScenes = new List<CustomDateScene>();

    [Header("Task Integration")]
    [SerializeField] private Color dateWithTasksColor = new Color(0.2f, 0.8f, 0.2f);

    private DateTime currentDate;
    private List<GameObject> spawnedDateButtons = new List<GameObject>();

    [System.Serializable]
    public class CustomDateScene
    {
        public int day;
        public int month;
        public string sceneName;
    }

    private void Start()
    {
        currentDate = DateTime.Now;
        previousButton.onClick.AddListener(PreviousMonth);
        nextButton.onClick.AddListener(NextMonth);
        backButton.onClick.AddListener(ReturnToMenu);
        addButton.onClick.AddListener(CreateTask);

        GenerateCalendar();
    }

    public void PreviousMonth()
    {
        currentDate = currentDate.AddMonths(-1);
        GenerateCalendar();
    }

    public void NextMonth()
    {
        currentDate = currentDate.AddMonths(1);
        GenerateCalendar();
    }

    private void GenerateCalendar()
    {
        ClearCalendar();

        monthText.text = currentDate.ToString("MMMM yyyy");

        DateTime firstDayOfMonth = new DateTime(currentDate.Year, currentDate.Month, 1);
        int totalDays = DateTime.DaysInMonth(currentDate.Year, currentDate.Month);

        int startingIndex = (int)firstDayOfMonth.DayOfWeek;

        for (int i = 0; i < startingIndex; i++)
        {
            GameObject emptyButton = Instantiate(dateButtonPrefab, datesParent);
            emptyButton.GetComponentInChildren<TextMeshProUGUI>().text = "";
            emptyButton.GetComponent<Button>().interactable = false;
            spawnedDateButtons.Add(emptyButton);
        }

        for (int day = 1; day <= totalDays; day++)
        {
            GameObject dateButton = Instantiate(dateButtonPrefab, datesParent);
            dateButton.GetComponentInChildren<TextMeshProUGUI>().text = day.ToString();

            int currentDay = day;
            dateButton.GetComponent<Button>().onClick.AddListener(() => OnDateSelected(currentDay));

            dateButton.name = $"DateButton_{day}";

            if (day == DateTime.Now.Day && currentDate.Month == DateTime.Now.Month && currentDate.Year == DateTime.Now.Year)
            {
                ColorBlock colors = dateButton.GetComponent<Button>().colors;
                colors.normalColor = new Color(0.8f, 0.9f, 1f);
                dateButton.GetComponent<Button>().colors = colors;
            }

            if (TaskManager.Instance != null && TaskManager.Instance.TasksLoaded)
            {
                string dateKey = $"{currentDate.Year}-{currentDate.Month:D2}-{day:D2}";
                List<Task> tasksForDate = TaskManager.Instance.GetTasksForDate(dateKey);

                if (tasksForDate != null && tasksForDate.Count > 0)
                {
                    ColorBlock colors = dateButton.GetComponent<Button>().colors;
                    colors.normalColor = dateWithTasksColor;
                    dateButton.GetComponent<Button>().colors = colors;
                }
            }

            spawnedDateButtons.Add(dateButton);
        }
    }

    private void ClearCalendar()
    {
        foreach (GameObject button in spawnedDateButtons)
        {
            Destroy(button);
        }
        spawnedDateButtons.Clear();
    }

    public void OnDateSelected(int day)
    {
        DateTime selectedDate = new DateTime(currentDate.Year, currentDate.Month, day);
        Debug.Log($"Selected Date: {selectedDate.ToString("d")}");

        PlayerPrefs.SetString("SelectedDate", selectedDate.ToString("yyyy-MM-dd"));

        string sceneToLoad = tasksSceneName;

        if (useCustomSceneNames)
        {
            foreach (CustomDateScene customDate in customDateScenes)
            {
                if (customDate.day == day && customDate.month == currentDate.Month)
                {
                    sceneToLoad = customDate.sceneName;
                    break;
                }
            }
        }

        if (SceneManager.GetSceneByName(sceneToLoad) != null || Application.CanStreamedLevelBeLoaded(sceneToLoad))
        {
            SceneManager.LoadScene(sceneToLoad);
        }
        else
        {
            Debug.LogError($"Scene '{sceneToLoad}' does not exist in the build settings.");
        }
    }

    public void ReturnToMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }

    private void CreateTask()
    {
        SceneManager.LoadScene("TaskCreator");
    }
}