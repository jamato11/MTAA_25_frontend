using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using TMPro;
using System.Linq;
using UnityEngine.SceneManagement;

[System.Serializable]
public class Task
{
    public int task_id;
    public string title;
    public string description;
    public string date;
    public string time;
    public int owner_user_id;
    public int? chat_id;
}

[System.Serializable]
public class TaskList
{
    public List<Task> tasks;
}

public class TaskManager : MonoBehaviour
{
    private static TaskManager _instance;

    [Header("API Configuration")]
    [SerializeField] private string apiBaseUrl = "http://127.0.0.1:5000/tasks";

    [Header("Calendar Integration")]
    [SerializeField] private Color taskDateColor = new Color(0.2f, 0.8f, 0.2f);

    private Dictionary<string, List<Task>> tasksByDate = new Dictionary<string, List<Task>>();
    private List<Task> allTasks = new List<Task>();
    private bool tasksLoaded = false;

    public static TaskManager Instance
    {
        get { return _instance; }
    }

    public List<Task> AllTasks => allTasks;
    public bool TasksLoaded => tasksLoaded;

    private void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);

            if (UserSessionManager.Instance != null && UserSessionManager.Instance.IsLoggedIn)
            {
                StartCoroutine(FetchTasksAfterDelay(UserSessionManager.Instance.GetCurrentUserId()));
            }
            else
            {
                Debug.LogWarning("TaskManager: No user is logged in, cannot fetch tasks");
                if (UserSessionManager.Instance != null)
                {
                    UserSessionManager.OnUserLogin += HandleUserLogin;
                }
            }
        }
        else if (_instance != this)
        {
            Destroy(gameObject);
        }
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnDestroy()
    {
        if (UserSessionManager.Instance != null)
        {
            UserSessionManager.OnUserLogin -= HandleUserLogin;
        }
    }

    private void HandleUserLogin(int userId)
    {
        if (userId > 0)
        {
            FetchTasksForUser(userId);
        }
    }

    private IEnumerator FetchTasksAfterDelay(int userId)
    {
        yield return new WaitForSeconds(0.5f);

        if (userId > 0)
        {
            FetchTasksForUser(userId);
        }
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name == "Calendar")
        {
            StartCoroutine(UpdateCalendarWhenTasksLoaded());
        }
        else if (scene.name == "Tasks")
        {
            DisplayTasksForSelectedDate();
        }
    }

    private IEnumerator UpdateCalendarWhenTasksLoaded()
    {
        while (!tasksLoaded)
        {
            yield return new WaitForSeconds(0.2f);
        }

        CalendarManager calendarManager = FindObjectOfType<CalendarManager>();
        if (calendarManager != null)
        {
            StartCoroutine(UpdateCalendarButtonColors(calendarManager));
        }
    }

    private IEnumerator UpdateCalendarButtonColors(CalendarManager calendarManager)
    {
        yield return new WaitForSeconds(0.3f);

        Transform datesParent = GameObject.Find("datesParent")?.transform;
        if (datesParent != null)
        {
            foreach (Transform child in datesParent)
            {
                Button btn = child.GetComponent<Button>();
                TextMeshProUGUI dateText = child.GetComponentInChildren<TextMeshProUGUI>();

                if (btn != null && dateText != null && !string.IsNullOrEmpty(dateText.text))
                {
                    int day;
                    if (int.TryParse(dateText.text, out day))
                    {
                        DateTime currentMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                        string dateKey = $"{currentMonth.Year}-{currentMonth.Month:D2}-{day:D2}";

                        if (tasksByDate.ContainsKey(dateKey) && tasksByDate[dateKey].Count > 0)
                        {
                            ColorBlock colors = btn.colors;
                            colors.normalColor = taskDateColor;
                            btn.colors = colors;
                        }
                    }
                }
            }
        }
    }

    public void FetchTasksForUser(int userId)
    {
        if (userId <= 0)
        {
            Debug.LogError("TaskManager: Invalid user ID for fetching tasks");
            return;
        }

        StartCoroutine(FetchTasksCoroutine(userId));
    }

    private IEnumerator FetchTasksCoroutine(int userId)
    {
        string url = $"{apiBaseUrl}/{userId}";

        using (UnityWebRequest request = UnityWebRequest.Get(url))
        {
            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError($"TaskManager: Error fetching tasks - {request.error}");
            }
            else
            {
                string jsonResponse = request.downloadHandler.text;
                Debug.Log($"TaskManager: Received tasks data: {jsonResponse}");

                try
                {
                    allTasks = JsonUtility.FromJson<TaskList>("{\"tasks\":" + jsonResponse + "}").tasks;

                    OrganizeTasksByDate();

                    tasksLoaded = true;
                    Debug.Log($"TaskManager: Loaded {allTasks.Count} tasks for user {userId}");
                }
                catch (Exception e)
                {
                    Debug.LogError($"TaskManager: Error parsing tasks data - {e.Message}");
                }
            }
        }
    }

    private void OrganizeTasksByDate()
    {
        tasksByDate.Clear();

        foreach (Task task in allTasks)
        {
            string dateKey = task.date;

            if (!tasksByDate.ContainsKey(dateKey))
            {
                tasksByDate[dateKey] = new List<Task>();
            }

            tasksByDate[dateKey].Add(task);
        }
    }

    private void DisplayTasksForSelectedDate()
    {
        string selectedDateStr = PlayerPrefs.GetString("SelectedDate", DateTime.Now.ToString("yyyy-MM-dd"));

        GameObject tasksPanel = GameObject.Find("TasksPanel");
        if (tasksPanel == null)
        {
            Debug.LogError("TaskManager: TasksPanel not found in Tasks scene");
            return;
        }

        TextMeshProUGUI titleText = GameObject.Find("Today")?.GetComponent<TextMeshProUGUI>();
        if (titleText != null)
        {
            DateTime selectedDate = DateTime.Parse(selectedDateStr);
            titleText.text = selectedDate.ToString("MMMM d, yyyy");
        }

        Transform taskContainer = GameObject.Find("ScrollView")?.transform.Find("Viewport")?.transform.Find("Content");
        if (taskContainer == null)
        {
            Debug.LogError("TaskManager: Task container not found in Tasks scene");
            return;
        }

        foreach (Transform child in taskContainer)
        {
            Destroy(child.gameObject);
        }

        if (tasksByDate.ContainsKey(selectedDateStr))
        {
            List<Task> tasksForDate = tasksByDate[selectedDateStr];

            foreach (Task task in tasksForDate)
            {
                GameObject taskItem = new GameObject("TaskItem");
                taskItem.transform.SetParent(taskContainer, false);

                TextMeshProUGUI taskText = taskItem.AddComponent<TextMeshProUGUI>();
                taskText.text = $"{task.title}";
                taskText.fontSize = 18;
                taskText.alignment = TextAlignmentOptions.Left;
            }
        }
    }

    public List<Task> GetTasksForDate(string dateStr)
    {
        if (tasksByDate.ContainsKey(dateStr))
        {
            return tasksByDate[dateStr];
        }

        return new List<Task>();
    }

    public void RefreshTasks()
    {
        if (UserSessionManager.Instance != null && UserSessionManager.Instance.IsLoggedIn)
        {
            FetchTasksForUser(UserSessionManager.Instance.GetCurrentUserId());
        }
    }
}