using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UpcomingTasksManager : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private Transform upcomingTasksContainer;
    [SerializeField] private GameObject taskItemPrefab;
    [SerializeField] private TextMeshProUGUI noTasksText;

    [Header("Settings")]
    [SerializeField] private int daysThreshold = 7;

    private void Start()
    {
        if (TaskManager.Instance != null && UserSessionManager.Instance != null && UserSessionManager.Instance.IsLoggedIn)
        {
            TaskManager.Instance.FetchTasksForUser(UserSessionManager.Instance.GetCurrentUserId());
            StartCoroutine(WaitForTasksToLoad());
        }
        else
        {
            Debug.LogWarning("UpcomingTasksManager: TaskManager or UserSessionManager not available or user not logged in");
            DisplayMessage("Please log in to view tasks");
        }
    }

    private void OnEnable()
    {
        if (TaskManager.Instance != null && TaskManager.Instance.TasksLoaded)
        {
            PopulateUpcomingTasks();
        }
    }

    private IEnumerator WaitForTasksToLoad()
    {
        DisplayMessage("Loading tasks...");

        float waitTime = 0f;
        float timeout = 10f;

        while ((TaskManager.Instance == null || !TaskManager.Instance.TasksLoaded) && waitTime < timeout)
        {
            yield return new WaitForSeconds(0.5f);
            waitTime += 0.5f;
        }

        if (TaskManager.Instance != null && TaskManager.Instance.TasksLoaded)
        {
            PopulateUpcomingTasks();
        }
        else
        {
            DisplayMessage("Could not load tasks. Please try again later.");
        }
    }

    private void DisplayMessage(string message)
    {
        if (upcomingTasksContainer == null)
        {
            Debug.LogError("UpcomingTasksManager: upcomingTasksContainer not assigned");
            return;
        }

        foreach (Transform child in upcomingTasksContainer)
        {
            Destroy(child.gameObject);
        }

        GameObject messageObj = new GameObject("MessageText");
        messageObj.transform.SetParent(upcomingTasksContainer, false);

        TextMeshProUGUI tmpText = messageObj.AddComponent<TextMeshProUGUI>();
        tmpText.text = message;
        tmpText.fontSize = 16;
        tmpText.alignment = TextAlignmentOptions.Center;
        tmpText.color = Color.gray;

        RectTransform rectTransform = messageObj.GetComponent<RectTransform>();
        rectTransform.anchorMin = Vector2.zero;
        rectTransform.anchorMax = Vector2.one;
        rectTransform.offsetMin = Vector2.zero;
        rectTransform.offsetMax = Vector2.zero;
    }

    public void PopulateUpcomingTasks()
    {
        if (upcomingTasksContainer == null)
        {
            Debug.LogError("UpcomingTasksManager: upcomingTasksContainer not assigned");
            return;
        }

        foreach (Transform child in upcomingTasksContainer)
        {
            Destroy(child.gameObject);
        }

        List<Task> upcomingTasks = GetUpcomingTasks();

        if (upcomingTasks.Count == 0)
        {
            if (noTasksText != null)
            {
                noTasksText.gameObject.SetActive(true);
                noTasksText.text = "No upcoming deadlines";
            }
            else
            {
                GameObject noTasksObj = new GameObject("NoTasksText");
                noTasksObj.transform.SetParent(upcomingTasksContainer, false);

                TextMeshProUGUI tmpText = noTasksObj.AddComponent<TextMeshProUGUI>();
                tmpText.text = "No upcoming deadlines";
                tmpText.fontSize = 16;
                tmpText.alignment = TextAlignmentOptions.Center;
                tmpText.color = Color.gray;
            }
            return;
        }

        if (noTasksText != null)
        {
            noTasksText.gameObject.SetActive(false);
        }

        foreach (Task task in upcomingTasks)
        {
            CreateTaskItem(task);
        }
    }

    private List<Task> GetUpcomingTasks()
    {
        List<Task> upcomingTasks = new List<Task>();
        DateTime currentDate = DateTime.Now.Date;

        foreach (Task task in TaskManager.Instance.AllTasks)
        {
            if (DateTime.TryParse(task.date, out DateTime taskDate))
            {
                TimeSpan timeUntilDeadline = taskDate.Date - currentDate;

                if (timeUntilDeadline.TotalDays >= 0 && timeUntilDeadline.TotalDays <= daysThreshold)
                {
                    upcomingTasks.Add(task);
                }
            }
        }

        upcomingTasks.Sort((a, b) =>
        {
            DateTime dateA = DateTime.Parse(a.date);
            DateTime dateB = DateTime.Parse(b.date);
            return dateA.CompareTo(dateB);
        });

        return upcomingTasks;
    }

    private void CreateTaskItem(Task task)
    {
        GameObject taskItemObj;

        if (taskItemPrefab != null)
        {
            taskItemObj = Instantiate(taskItemPrefab, upcomingTasksContainer);
        }
        else
        {
            taskItemObj = new GameObject("TaskItem");
            taskItemObj.transform.SetParent(upcomingTasksContainer, false);

            RectTransform rectTransform = taskItemObj.AddComponent<RectTransform>();
            rectTransform.sizeDelta = new Vector2(upcomingTasksContainer.GetComponent<RectTransform>().rect.width, 40);

            ContentSizeFitter fitter = taskItemObj.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            TextMeshProUGUI taskText = taskItemObj.AddComponent<TextMeshProUGUI>();
            taskText.fontSize = 16;
            taskText.alignment = TextAlignmentOptions.Left;

            GameObject checkmarkContainer = new GameObject("CheckmarkContainer");
            RectTransform checkRT = checkmarkContainer.AddComponent<RectTransform>();
            checkRT.SetParent(taskItemObj.transform, false);
            checkRT.anchorMin = new Vector2(1, 0.5f);
            checkRT.anchorMax = new Vector2(1, 0.5f);
            checkRT.pivot = new Vector2(1, 0.5f);
            checkRT.sizeDelta = new Vector2(32, 32);
            checkRT.anchoredPosition = new Vector2(-10, 0);

            Toggle toggle = checkmarkContainer.AddComponent<Toggle>();

            GameObject checkmarkImg = new GameObject("Checkmark");
            Image img = checkmarkImg.AddComponent<Image>();
            img.color = new Color(0f, 0.75f, 0f);
            RectTransform imgRT = img.rectTransform;
            imgRT.SetParent(checkmarkContainer.transform, false);
            imgRT.anchorMin = Vector2.zero;
            imgRT.anchorMax = Vector2.one;
            imgRT.sizeDelta = Vector2.zero;

            toggle.graphic = img;
            toggle.isOn = false;
        }

        TextMeshProUGUI textComponent = taskItemObj.GetComponentInChildren<TextMeshProUGUI>();
        if (textComponent != null)
        {
            DateTime taskDate = DateTime.Parse(task.date);
            string dateStr = taskDate.ToString("MMM d");

            textComponent.text = $"{task.title} - {dateStr}";

            TimeSpan timeUntilDeadline = taskDate.Date - DateTime.Now.Date;
            if (timeUntilDeadline.TotalDays <= 2)
            {
                textComponent.color = new Color(0.9f, 0.2f, 0.2f);
            }
        }

        Button taskButton = taskItemObj.GetComponent<Button>();
        if (taskButton == null && taskItemPrefab == null)
        {
            taskButton = taskItemObj.AddComponent<Button>();
            ColorBlock colors = taskButton.colors;
            colors.highlightedColor = new Color(0.8f, 0.8f, 0.8f, 0.5f);
            taskButton.colors = colors;
        }

        if (taskButton != null)
        {
            TaskItemData taskData = taskItemObj.GetComponent<TaskItemData>();
            if (taskData == null)
            {
                taskData = taskItemObj.AddComponent<TaskItemData>();
            }
            taskData.taskId = task.task_id;

            taskButton.onClick.AddListener(() => OnTaskItemClicked(task));
        }
    }

    private void OnTaskItemClicked(Task task)
    {
        Debug.Log($"Task clicked: {task.title}");
        PlayerPrefs.SetString("SelectedDate", task.date);
        SceneManager.LoadScene("Tasks");
    }
}

public class TaskItemData : MonoBehaviour
{
    public int taskId;
}