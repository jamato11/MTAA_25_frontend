using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class TaskListManager : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private TextMeshProUGUI dateHeaderText;
    [SerializeField] private Transform taskListContent;
    [SerializeField] private GameObject taskItemPrefab;
    [SerializeField] private Button leftArrowButton;
    [SerializeField] private Button rightArrowButton;
    [SerializeField] private Button backButton;

    private DateTime selectedDate;
    private string selectedDateString;

    private void Start()
    {
        selectedDateString = PlayerPrefs.GetString("SelectedDate", DateTime.Now.ToString("yyyy-MM-dd"));
        selectedDate = DateTime.Parse(selectedDateString);

        if (dateHeaderText != null)
        {
            dateHeaderText.text = selectedDate.ToString("MMMM d, yyyy");
        }

        if (leftArrowButton != null)
        {
            leftArrowButton.onClick.AddListener(PreviousDay);
        }

        if (rightArrowButton != null)
        {
            rightArrowButton.onClick.AddListener(NextDay);
        }

        if (backButton != null)
        {
            backButton.onClick.AddListener(BackToCalendar);
        }

        DisplayTasksForSelectedDate();
    }

    private void DisplayTasksForSelectedDate()
    {
        foreach (Transform child in taskListContent)
        {
            Destroy(child.gameObject);
        }

        if (TaskManager.Instance != null && TaskManager.Instance.TasksLoaded)
        {
            List<Task> tasksForDate = TaskManager.Instance.GetTasksForDate(selectedDateString);

            if (tasksForDate != null && tasksForDate.Count > 0)
            {
                foreach (Task task in tasksForDate)
                {
                    CreateTaskItem(task);
                }
            }
            else
            {
                GameObject emptyObj = new GameObject("EmptyMessage");
                emptyObj.transform.SetParent(taskListContent, false);

                TextMeshProUGUI emptyText = emptyObj.AddComponent<TextMeshProUGUI>();
                emptyText.text = "No tasks for this date";
                emptyText.fontSize = 18;
                emptyText.color = Color.gray;
                emptyText.alignment = TextAlignmentOptions.Center;
            }
        }
        else
        {
            GameObject loadingObj = new GameObject("LoadingMessage");
            loadingObj.transform.SetParent(taskListContent, false);

            TextMeshProUGUI loadingText = loadingObj.AddComponent<TextMeshProUGUI>();
            loadingText.text = "Loading tasks...";
            loadingText.fontSize = 18;
            loadingText.color = Color.gray;
            loadingText.alignment = TextAlignmentOptions.Center;

            if (TaskManager.Instance != null && UserSessionManager.Instance != null && UserSessionManager.Instance.IsLoggedIn)
            {
                TaskManager.Instance.FetchTasksForUser(UserSessionManager.Instance.GetCurrentUserId());
                StartCoroutine(RefreshWhenTasksLoaded());
            }
        }
    }

    private IEnumerator RefreshWhenTasksLoaded()
    {
        yield return new WaitForSeconds(1f);

        if (TaskManager.Instance != null && TaskManager.Instance.TasksLoaded)
        {
            DisplayTasksForSelectedDate();
        }
        else
        {
            StartCoroutine(RefreshWhenTasksLoaded());
        }
    }

    private void CreateTaskItem(Task task)
    {
        if (taskItemPrefab != null)
        {
            GameObject taskItemGO = Instantiate(taskItemPrefab, taskListContent);

            TextMeshProUGUI titleText = taskItemGO.GetComponentInChildren<TextMeshProUGUI>();
            if (titleText != null)
            {
                titleText.text = task.title;
            }
        }
        else
        {
            GameObject taskItemGO = new GameObject($"Task_{task.task_id}");
            taskItemGO.transform.SetParent(taskListContent, false);

            HorizontalLayoutGroup layout = taskItemGO.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = 10f;
            layout.childAlignment = TextAnchor.MiddleLeft;
            layout.padding = new RectOffset(5, 5, 5, 5);

            GameObject checkObj = new GameObject("Checkbox");
            checkObj.transform.SetParent(taskItemGO.transform, false);
            Toggle toggle = checkObj.AddComponent<Toggle>();

            GameObject checkmarkObj = new GameObject("Checkmark");
            checkmarkObj.transform.SetParent(checkObj.transform, false);
            Image checkmark = checkmarkObj.AddComponent<Image>();
            checkmark.color = Color.green;
            toggle.graphic = checkmark;

            GameObject titleObj = new GameObject("Title");
            titleObj.transform.SetParent(taskItemGO.transform, false);
            TextMeshProUGUI titleText = titleObj.AddComponent<TextMeshProUGUI>();
            titleText.text = task.title;
            titleText.fontSize = 16;
            titleText.color = Color.black;

            LayoutElement checkLayout = checkObj.AddComponent<LayoutElement>();
            checkLayout.minWidth = 24;
            checkLayout.minHeight = 24;

            LayoutElement titleLayout = titleObj.AddComponent<LayoutElement>();
            titleLayout.flexibleWidth = 1;
        }
    }

    private void PreviousDay()
    {
        selectedDate = selectedDate.AddDays(-1);
        UpdateSelectedDate();
    }

    private void NextDay()
    {
        selectedDate = selectedDate.AddDays(1);
        UpdateSelectedDate();
    }

    private void UpdateSelectedDate()
    {
        selectedDateString = selectedDate.ToString("yyyy-MM-dd");
        PlayerPrefs.SetString("SelectedDate", selectedDateString);

        if (dateHeaderText != null)
        {
            dateHeaderText.text = selectedDate.ToString("MMMM d, yyyy");
        }

        DisplayTasksForSelectedDate();
    }

    private void BackToCalendar()
    {
        SceneManager.LoadScene("Calendar");
    }
}